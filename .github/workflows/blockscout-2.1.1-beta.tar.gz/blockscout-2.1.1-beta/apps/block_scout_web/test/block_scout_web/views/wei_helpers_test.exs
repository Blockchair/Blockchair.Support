defmodule BlockScoutWeb.WeiHelpersTest do
  use ExUnit.Case

  # Needed for doctest
  alias Explorer.Chain.Wei

  doctest BlockScoutWeb.WeiHelpers, import: true
end
