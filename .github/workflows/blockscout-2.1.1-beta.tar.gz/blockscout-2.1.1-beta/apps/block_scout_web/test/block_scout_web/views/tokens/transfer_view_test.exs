defmodule BlockScoutWeb.Tokens.TransferViewTest do
  use BlockScoutWeb.ConnCase, async: true
end
