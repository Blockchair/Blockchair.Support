import '../../css/stakes.scss'
