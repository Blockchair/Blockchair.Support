defmodule BlockScoutWeb.Tokens.InstanceView do
  use BlockScoutWeb, :view
end
