defmodule BlockScoutWeb.Tokens.ReadContractView do
  use BlockScoutWeb, :view

  alias BlockScoutWeb.Tokens.OverviewView
end
