defmodule BlockScoutWeb.Admin.SetupView do
  use BlockScoutWeb, :view

  import BlockScoutWeb.AdminRouter.Helpers

  alias BlockScoutWeb.FormView
end
