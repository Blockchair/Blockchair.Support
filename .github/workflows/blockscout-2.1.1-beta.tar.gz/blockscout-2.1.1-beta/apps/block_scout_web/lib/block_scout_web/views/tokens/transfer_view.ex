defmodule BlockScoutWeb.Tokens.TransferView do
  use BlockScoutWeb, :view

  alias BlockScoutWeb.Tokens.OverviewView
end
