defmodule BlockScoutWeb.AddressTokenView do
  use BlockScoutWeb, :view
end
