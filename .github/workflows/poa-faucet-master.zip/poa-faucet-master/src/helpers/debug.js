function debug (isDebug, text) {
	if (isDebug) {
  		console.log(text)
	}
}
module.exports = { debug }